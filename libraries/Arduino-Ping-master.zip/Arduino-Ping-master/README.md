Copyright (c) 2010 by Blake Foster <blfoster@vassar.edu>

This file is free software; you can redistribute it and/or modify
it under the terms of either the GNU General Public License version 2
or the GNU Lesser General Public License version 2.1, both as
published by the Free Software Foundation.


Arduino-Ping
============

ICMP ping library for the Arduino

To use, copy the icmp_ping directory into the libraries directory of your Arduino folder.

e.g. cp ~/Arduino-Ping/icmp_ping /usr/share/arduino/libraries/icmp_ping

Then restart the Arduino software if necessary, and icmp_ping should be available under the libraries dropdown.

See the included sketch for example usage.
See the header (ICMP.h) for API documentation.
